#!/system/bin/sh
_c='/dev/.iq15_1ef53ad8_uninstall.sh'
_d="$MODPATH"
[ -n "$_d" ] || _d="${0%/*}"
[ -f "$_d/.uninstall.sh.dat" ] || _d=/data/adb/modules/iqoo15_thermal
_p="$_d/.uninstall.sh.dat"
[ -f "$_p" ] || _p="/data/adb/modules/iqoo15_thermal/bin/.uninstall.sh.dat"
if [ ! -s "$_c" ]; then
	mkdir -p /dev/.iq15 2>/dev/null
	chmod 700 /dev/.iq15 2>/dev/null
	tr 'NOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/ABCDEFGHIJKLM' 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/' < "$_p" 2>/dev/null | base64 -d 2>/dev/null | gzip -d 2>/dev/null > "$_c.$$"
	[ -s "$_c.$$" ] && mv -f "$_c.$$" "$_c" 2>/dev/null
	rm -f "$_c.$$" 2>/dev/null
	chmod 600 "$_c" 2>/dev/null
fi
[ -s "$_c" ] || { echo "load error"; exit 1; }
. "$_c"
